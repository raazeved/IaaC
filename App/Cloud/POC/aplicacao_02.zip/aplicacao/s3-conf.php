<?php
$accessKey = 'AKIA4UPIHQLWBXOKR3J3';
$secretKey = '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';
$region = 'us-east-1';
$bucket = 'imagens-bootcamp-cloud1';
$arqName =  'logo.jpg';
?>
